import re, subprocess, sys, pathlib
root = pathlib.Path(__file__).resolve().parent
AUTEUR = "Lisa Blondel"
def fr(t):
    t = t.replace("« ", "«\\,").replace(" »", "\\,»")
    t = re.sub(r" :", "~:", t)
    t = re.sub(r" ([;!?])", r"\\,\1", t)
    return t
for n in ("corps", "biblio"):
    s = (root/"src"/f"{n}_src.tex").read_text()
    (root/f"{n}.tex").write_text(fr(s))
def build(blank):
    cfg = "\\newcommand{\\AUTEUR}{%s}\n\\newcommand{\\PAGESBLANCHES}{%s}\n" % (AUTEUR, "".join(r"\null\newpage" for _ in range(blank)))
    (root/"config.tex").write_text(cfg)
    for _ in range(2):
        r = subprocess.run(["xelatex","-interaction=nonstopmode","-halt-on-error","main.tex"],cwd=root,capture_output=True,text=True)
        if r.returncode: print(r.stdout[-3000:]); sys.exit(1)
    out = subprocess.run(["pdfinfo","main.pdf"],cwd=root,capture_output=True,text=True).stdout
    return int(re.search(r"Pages:\s+(\d+)",out).group(1))
n = build(0)
extra = (-n) % 4
if extra: n = build(extra)
print("pages:", n, "blanks added:", extra)
